import sys

from jupyterlab.labapp import main

sys.exit(main())
