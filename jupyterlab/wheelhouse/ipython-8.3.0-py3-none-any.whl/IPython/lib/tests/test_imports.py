# encoding: utf-8
from IPython.testing import decorators as dec

def test_import_backgroundjobs():
    from IPython.lib import backgroundjobs

def test_import_deepreload():
    from IPython.lib import deepreload

def test_import_demo():
    from IPython.lib import demo
