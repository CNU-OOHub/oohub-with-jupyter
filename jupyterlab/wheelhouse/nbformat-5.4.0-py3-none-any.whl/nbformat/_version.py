# Make sure to update package.json, too!
version_info = (5, 4, 0)
__version__ = ".".join(map(str, version_info))
