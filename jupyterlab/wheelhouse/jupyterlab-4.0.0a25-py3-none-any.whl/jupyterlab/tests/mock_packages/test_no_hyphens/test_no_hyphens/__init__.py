def _jupyter_labextension_paths():
    return [{"src": "labextension", "dest": "test_no_hyphens"}]
